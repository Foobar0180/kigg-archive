# KiGG Deployment Guide Part 1

# Related topics
* [Deployment Guide Part 2](Deployment-Guide-Part-2)

## Introduction
This document is concerned with how to deploy KiGG (**Clean Installation**) on your server or local development machine using SQL Server 2005 or later. Assuming full trust is supported. Before you go further you'll need to download the deployment package for KiGG v2.5 [here](http://kigg.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=28200)
Extract the deployment package (not the source code) on your local drive and follow the below sections with steps for initial deployment.
The document will cover the following:
* Creating the database
* Configuring KiGG to use Entity Framework or LINQ to SQL
* Configuring KiGG Connection String
* Configuring KiGG Default -initial- Users

This part of deployment guide will not go through how to configure external services such as PageGlimpse, twitter, reCaptcha etc... These will be covered on another part.

**Attachements:** [KiGG 2.5 Sample Configuration](Deployment Guide Part 1_KiGG25Config.zip) (web.config, unity.ef.config & unity.l2s.config)

## Database installation for SQL Server
This section will show how to create a KiGG database on SQL Server based on KiGG database script available with the deployment package.

### Physical database creation
# Under "DatabaseScripts\SQLServer" folder you'll find a SQL script file "Create.sql". Open this file with your SQL Server Management Studio. By default this file will create a database with name KiGG. Feel free to change this name by editing the first line on the script "_CREATE DATABASE {"[KiGG](KiGG)"}_". You'll just need to change "_KiGG_" to something else e.g. "_KiGGCleanInstall_"
# Run the script by clicking on the execute button.

The above steps simply showed how to create a clean empty KiGG database on SQL Server 2005 or later.

### Inserting pre-defined categories
Because we just created an empty database, we will need to initialize it with few mandatory records which are KiGG Categories. KiGG currently dosen't support management Categories. So we will need to create them manually by T-SQL script.
# Under DatabaseScripts\SQLServer"" folder open "Data.sql" file. This file contains the pre-defined categories. If you c hanged your database name on the above section, make sure to do that same on this file before your execute it. On first line "_Use {"[KiGG](KiGG)"}_" you can change it to be "_Use {"[YOUR DATABASE NAME](YOUR-DATABASE-NAME)"}_".
# Run the script by clicking execute button.

The above steps showed how to create manually using T-SQL pre-defined categories. Feel free to change the fine according to your needs. This is definitely what everyone would do.

## Creating KiGG virtual directory or Web Site under your IIS
Actually I won't go further into this point, I'll assume you create a virtual directory under existing default site of your local IIS or create a special IIS web site for KiGG. Personally while writing this guide I create a special web site with specific port under my local IIS 7.0. Here what exactly I did
# Create a root folder under your "Inetpub", call it "KiGGRoot" for example.
# Under your deployment package folder, copy the content of "Web" Folder -not the web folder itself- and paste it under the "KiGGRoot" folder we defined in step 1
# Open your IIS Manager and create new Web Site, Specify the location of Content Directory to be your "KiGGRoot" folder created in step 1. Specify a port and that is it.

## Basic KiGG Configurations
In this section we will see how to configure KiGG to use Entity Framework or LINQ to SQL as well as configuring KiGG databsae connection string name map it to EF or LINQ to SQL unity configuration.

### Configuring KiGG to Entity Framework or LINQ to SQL
# Open the _web.config_ file and fine _unity_ element.
# If you wish to use Entity Framework make sure that the _configSource_ attribute value is "unity.ef.config". But if you wish to go with LINQ to SQL then the value should be "unity.l2s.config".
Unity mapping for Entity Framework unity configuration. For detail deep information about this configuration read [KiGG Entity Framework Configuration](KiGG-Entity-Framework-Configuration).
{code:xml}
<unity configSource="unity.ef.config"/>
{code:xml}
Unity mapping for LINQ to SQL unity configuration
{code:xml}
<unity configSource="unity.l2s.config"/>
{code:xml}

### Configuring Connection String
# Open the _web.config_ file and fine _connectionStrings_ element.
# You'll find 2 entries under connectionStrings element. On for SQL Server with name "_KiGGSqlServer_" and the other with name "_KiGGMySql_". We are now only concerned with SQL Server connection string.
# Modify KiGGSqlServer connection string entry _value_ attribute. Your final results should be close to this:
{code:xml}
<connectionStrings>
    <clear/>
    <add name="KiGGSqlServer"
         connectionString="Data Source=.;Database=KiGG;uid=YOURDATABASEUSERNAME;password=YOURDATABASEPASSWORD;"
         providerName="System.Data.SqlClient"/>
    <add name="KiGGMySql"
         connectionString="server=localhost;user id=root;password=Pa$$w0rd;persist security info=True;database=KiGG"
         providerName="MySql.Data.MySqlClient"/>
</connectionStrings>
{code:xml} 
**Note:** You are free to change your connection string name, but make sure you update your unity configuration to map to the new connection string name. Read [KiGG Entity Framework Configuration](KiGG-Entity-Framework-Configuration) for more details.

### Confirming connection string name in "_unity.ef.config_" (for entity framework) and "_unity.l2s.config_" (for LINQ to SQL)
In this section we will review the unity configuration to make sure that our connection string name is correctly mapped. This is to avoid any initial exception because of specifying incorrect connection string name in unity configuration.

We will start with Entity Framework Unity Configuration "**unity.ef.config**" open this file and do the following:
# Search for the following string "_<type type="IConnectionString" mapTo="ConnectionString">_" this is propably would be line 537 in the attached file to this Guide.
# Make sure that the connection string name is specified for parameter "name" of the _ConnectionString_ class. It should be something like the below:
{code:xml}
<type type="IConnectionString" mapTo="ConnectionString">
  <lifetime type="Singleton"/>
  <typeConfig extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <constructor>
      <param name="configuration" parameterType="IConfigurationManager">
        <dependency/>
      </param>
      <param name="_name_" parameterType="System.String">
        <value type="System.String" value="KiGGSqlServer"/> <!--Connection string name specified here-->
      </param>
      <param name="edmFilesPath" parameterType="System.String">
        <value type="System.String" value="|DataDirectory|"/>
      </param>
      <param name="ssdlFileName" parameterType="System.String">
        <value type="System.String" value="DomainObjects.SqlServer"/>
      </param>
    </constructor>
  </typeConfig>
</type>
{code:xml}

**Note:** Current deployment package has mistake that the connection string specified in the mapping is KiGGDatabase and not KiGGSqlServer.

Now we will need to do that same for LINQ to SQL Unity Configuration. Just repeat the above steps but with "**unity.l2s.config**" file.

**Note:** You might just do the above steps for single configuration (EF or LINQ to SQL). Just the file you are going to use. I documented both for consistency

### Configuring KiGG default users
By default once your run KiGG for the very first time, 3 default user will be created for your. The users are _admin_, _support_ and _bee_. These users are configurable. And you can add more default users or change existing ones attributes such as username, password, e-mail and role.

To configure default users on both Entity Framework and LINQ to SQL open related configuration file "unity.ef.config" or "unity.l2s.config" and do the following:
# Search for "_type="DefaultUser"_". You'll fine 3 results by default for the 3 defualt users mentioned above
# On each result you can change parapertes for UserName, Password, Email and Role. For example to change admin user password you can change Password parameter value. Below is sample configuration for default users
{code:xml}
<type name="admin" type="DefaultUser"> <!--Configuration for Admin User -->
  <lifetime type="Singleton"/>
  <typeConfig 
extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <property name="UserName" propertyType="System.String"> <!--UserName parameter -->
      <value type="System.String" value="admin"/>
    </property>
    <property name="Password" propertyType="System.String"> <!--Password parameter -->
      <value type="System.String" value="admin"/> <!--Change this value if you wish -->
    </property>
    <property name="Email" propertyType="System.String"> <!--Email parameter -->
      <value type="System.String" value="admin@YOUR-DOMAIN.com"/>
    </property>
    <property name="Role" propertyType="Roles"> <!--Role Parameter -->
      <value type="Roles" value="Administrator"/> <!--Role Possible Values are (Administrator, Moderator, Bot and User) -->
    </property>
  </typeConfig>
</type>
<type name="support" type="DefaultUser">
  <lifetime type="Singleton"/>
  <typeConfig 
extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <property name="UserName" propertyType="System.String">
      <value type="System.String" value="support"/>
    </property>
    <property name="Password" propertyType="System.String">
      <value type="System.String" value="support"/>
    </property>
    <property name="Email" propertyType="System.String">
      <value type="System.String" value="support@YOUR-DOMAIN.com"/>
    </property>
    <property name="Role" propertyType="Roles">
      <value type="Roles" value="Moderator"/>
    </property>
  </typeConfig>
</type>
<type name="bee" type="DefaultUser">
  <lifetime type="Singleton"/>
  <typeConfig 
extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <property name="UserName" propertyType="System.String">
      <value type="System.String" value="bee"/>
    </property>
    <property name="Password" propertyType="System.String">
      <value type="System.String" value="iambusy"/>
    </property>
    <property name="Email" propertyType="System.String">
      <value type="System.String" value="bee@YOUR-DOMAIN.com"/>
    </property>
    <property name="Role" propertyType="Roles">
      <value type="Roles" value="Bot"/>
    </property>
  </typeConfig>
</type>
{code:xml}

If you wish to add new user just copy one of the above type sections, change _type_ element _name_ attribute and parameter values for UserName, Password, Email and Role, as the following
{code:xml}
<type name="testUser" type="DefaultUser">
  <lifetime type="Singleton"/>
  <typeConfig 
extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <property name="UserName" propertyType="System.String">
      <value type="System.String" value="testUser"/>
    </property>
    <property name="Password" propertyType="System.String">
      <value type="System.String" value="Pa$$w0rd"/>
    </property>
    <property name="Email" propertyType="System.String">
      <value type="System.String" value="testUser@YOUR-DOMAIN.com"/>
    </property>
    <property name="Role" propertyType="Roles">
      <value type="Roles" value="User"/>
    </property>
  </typeConfig>
</type>
{code:xml}

## Conclusion
Now after you completed this part, you can now run your KiGG application for first time. A sample configuration files are attached for reference feel free to [download](Deployment Guide Part 1_KiGG25Config.zip)
them and use them as base for your KiGG v2.5 configuration.
This part covered what is critical to make your KiGG application run. In next parts we will cover how to go further in KiGG settings and how to configure external services such as twitter, PageGlimpse etc... So stay tuned and we appreciate your patience.