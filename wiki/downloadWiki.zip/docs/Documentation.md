# KiGG Documentation
This page is a documentation index for several sections and aspects of KiGG Project. Here you should find related documentation and guides for deployment and configuration of KiGG. Also you'll find related technical details about KiGG design and architecture. Some resources might link to external sites.

## System Requirements
### Deployment Server System Requirements
* .Net Framework 3.5 SP1
* ASP.NET MVC 1.0 RTM
* Database (Only one option is required)
	* SQL Server 2005 or later any Edition with Full-Text Search Services (Full-Text search is required for search)
	* MySQL 5.x
* IIS 6.0 or IIS 7.0 (didn't test it on Windows XP IIS 5.5)
* Partial Trust is supported if outbound http requests are allowed. Kindly refer to "[discussion:Medium trust level Problem](53367)"
**Note:** More into Partial trust will be provided in the documentation

### Development Workstation System Requirements
* Visual Studio.Net 2008 any edition with SP1 (Express Editions should work)
* .Net Framework 3.5 SP1
* ASP.NET MVC 1.0 RTM
* Included reference libraries (xUnit, Moq, DotNetOpenAuth, Enterprise Library etc...) -available with source code download-
* Database (Only one option is required)
	* SQL Server 2005 or later any Edition with Full-Text Search Services (Full-Text search is required for search)
	* MySQL 5.x
* IIS 6.0 or IIS 7.0 (didn't test it on Windows XP IIS 5.5)

## Deployment Guide
* [Deployment Guide Part 1](Deployment-Guide-Part-1). This part covers the following:
	* Database creation
	* KiGG configuration to use Entity Framework or LINQ to SQL
	* KiGG database connection String configuration
	* KiGG default -initial- users configuration (automated initial users creation)
* [Deployment Guide Part 2](Deployment-Guide-Part-2). This part covers the following:
	* Partial trust support (issues and solutions)
	* KiGG Configuration Settings. This covers how to set few global KiGG settings/properties such as Site Title, Meta keywords/description, admin/support emails etc...
* [Deployment Guide Part 3](Deployment-Guide-Part-3). This part covers the following:  _UNDER CONSTRUCTION_
	* Setting up external services such as reCAPTCHA, ping services, twitter integration, PageGlimpse or WebSnapr web thumbnail services etc.....

## Entity Framework Detailed Configuration
* [KiGG Entity Framework Configuratio](KiGG-Entity-Framework-Configuratio). This section has detailed information about how to configure KiGG Entity Framework repositories.
* [Configuring KiGG to use MySQL Database through Entity Framework](Configuring-KiGG-to-use-MySQL-Database-through-Entity-Framework). How to configure KiGG to use MySQL Database using Entity Framework.