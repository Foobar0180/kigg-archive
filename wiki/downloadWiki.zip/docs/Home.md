# Welcome to KiGG

## Announcements
* KiGG 4.0 is work on progress. Will be a total revamp and there could be breaking changes :(. Sorry for this. But will try to provide migration guide once ready. Not sure when a public beta release will be ready yet.
* KiGG 3.0 with MVC 2.0 RTM support on .Net 3.5 SP1-VS2008 [release:released](53838)
* KiGG 2.6 with MVC 2.0 RTM support demo is online on staging [KiGG v2.6 Beta](http://amconlinebd.web702.discountasp.net/KiGG)
* KiGG code base is upgraded to ASP.Net MVC 2 RTM on .Net 3.5 SP1. [Change set 38916](http://kigg.codeplex.com/SourceControl/changeset/view/38916)
* KiGG 2.5 Released [Check it out](http://kigg.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=28200)
* [Documentation](Documentation) page now available -_still topics under construction_- but you can check the initial [Deployment Guide Part 1](Deployment-Guide-Part-1) for getting started.
* For localization ideas and solution discussion followup on  [discussion:this thread](68844)

## Project Description
KiGG is a Web 2.0 style social news web application developed in Microsoft supported technologies.

## Project Bio
+MS Tooling:+
* ASP.NET MVC
* Linq To SQL or [Entity Framework](KiGG-Entity-Framework-Configuration)
* MS Patterns & Practices – Enterprise Library (Logging & Caching)
* MS Patterns & Practices - Unity
* jQuery

+Databases+
* SQL Server 2005 & 2008 all editions
* [MySQL 5.x](Configuring-KiGG-to-use-MySQL-Database-through-Entity-Framework)

+Other Third party:+
* xUnit.net
* Moq
* HtmlAgilityPack
* DotNetOpenId
* jQuery UI  & Markitup

+External Service Integration:+
* PageGlimpse, WebSnapr - For thumbnail generation.
* Akismet, TypePad and Defensio. - Spam Protection.
* reCaptcha 
* Gravatar
* OpenID & Id Selector
* Url shrinking services (http://tinyurl.com & http://is.gd)

+Open Standard implementation:+
*  hAtom, hReview, hVote, xFolk etc.
*  OpenSearch
*  SiteMap (Standard, Mobile, News)
*  RSS/Atom

It demonstrates how to develop a very loosely coupled application with Microsoft tooling following the domain driven design. 

+**See it in Action**+
[DotNetShoutout.com](http://dotnetshoutout.com/)
[sharepoint community site](www.sharepointsidekick.com/)
[progg.ru](http://progg.ru/)
[dotnetomaniak](http://dotnetomaniak.pl/)
[PimpThisBlog](http://www.pimpthisblog.com/)

![](Home_poweredByKiGG.png)
If you are planning/using this platform, we would really appreciate if you put the above logo in your site which link back to this page

+**Latest Updates**+
{rss:url=http://weblogs.asp.net/rashid/rss.aspx?Tags=DotNetShoutout&AndTags=1,max=5,titlesOnly=true}
+**[Follow us in Twitter](http://twitter.com/KiGG/)**+