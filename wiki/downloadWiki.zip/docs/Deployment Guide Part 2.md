# KiGG Deployment Guide Part 2
## Introduction
In this part of deployment guide I'll go through how to use KiGG under partial trust security policy, what are the issues and suggested resolutions. Also we will look at how to do basic configuration for KiGG. That should include defining default site title, admin/support email addresses, meta keywords and description, number of stories to be shown per page etc... So basically this part will cover
* Partial trust support in KiGG
* Basic KiGG Configuration Settings

## KiGG Partial Trust Support
Partial trust environments are those environments that run under trust level _Low_, _Minimal_, _Medium_ or _High_, most important it is not a _Full Trust_ environment. There is a good old article about [How To: Use Medium Trust in ASP.NET 2.0](http://msdn.microsoft.com/en-us/library/ms998341.aspx). This article also applies here.

Generally when we choose to run applications under partial trust policy we usually pick _Medium_ trust level and above which include _High_ trust level. KiGG supports _High_ trust level with no modifications. But for _Medium_ trust a modification is required to enable HTTP outbound traffics; so WebPermission should be modified to allow outbound http and https traffic. This requirements due to the use of DotNetOpenAuth assembly which require this permission. You can refer to this thread  [discussion:Medium trust level Problem](53367) for more discussion details about this subject.

### Modify WebPermission to enable HTTP outbound traffics
This is applicable on local development machines and dedicated web hosting. Shared hosting such as [GoDaddy](http://help.godaddy.com/article/1039) has this configuration made as well.
To apply this modification you should do the following:
# Go to %windir\Microsoft.NET\Framework\v2.0.50727\CONFIG folder. or %windir\Microsoft.NET\Frameworkx64\v2.0.50727\CONFIG -for x64 systems-
# Under this folder you'll find "**[web_mediumtrust.config](Deployment Guide Part 2_web_mediumtrust.config)**". Take a backup from it then open it to modify it.
# Find the following WebPermission settings and change it:
{code:xml}
<!--Before-->
<IPermission class="WebPermission" version="1" Unrestricted="true">
  <ConnectAccess>
    <URI uri="$OriginHost$"/>
  </ConnectAccess>
</IPermission>
{code:xml}
{code:xml}
<!--After-->
<IPermission class="WebPermission" version="1" Unrestricted="true"/>
{code:xml}

### Partial trust issue with Entity Framework
At the time of writing this my .Net framework 3.5 SP1 is up-to-date with latest August updates to Visual Studio.Net 2008 SP1. I am mentioning this because I will highlight an [issue with Entity Framework with partial trust](http://stackoverflow.com/questions/1424309/entity-framework-in-partial-trust-environment) that doesn't exist before this update. This issue is only with Entity Framework, if you choose to work with LINQ to SQL then there is no issue.

[The issue is now Entity Framework require SecurityPermission with UnmanagedCode flag](http://social.msdn.microsoft.com/Forums/en-US/adodotnetentityframework/thread/f31bb0d8-9ba7-411a-8c4a-63c24b866501). That wasn't the case on last June/July 09. Because I tested it and it was working fine. I guess there were some security update applied that causes this issue to take place. And so partial trust support might not be supported if you have (or your shared hosting have) recent updates of post .Net Framework 3.5 SP1 applied.

Anyway, I've included another partial trust configuration that has UnmanagedCode flag set for SecurityPermission you can download the file [web_mediumtrust_UnmanagedCode.config](Deployment Guide Part 2_web_mediumtrust_UnmanagedCode.config).
{code:xml}
<!--Before-->
<IPermission class="SecurityPermission" version="1" Flags="Assertion, Execution, ControlThread, ControlPrincipal, RemotingConfiguration"/>
{code:xml}
{code:xml}
<!--After-->
<IPermission class="SecurityPermission" version="1" Flags="Assertion, Execution, ControlThread, ControlPrincipal, RemotingConfiguration, UnmanagedCode"/>
{code:xml}

## Overview of KiGG Configuration Settings
What is meant by KiGG Configuration Settings here is the settings defined for _IConfigurationSettings_ type in unity configuration. These settings are identical in both files "_unity.ef.config_" & "_unity.l2s.config_".The following snippet shows settings with default values.
{code:xml}
<type type="IConfigurationSettings" mapTo="ConfigurationSettings">
  <lifetime type="Singleton"/>
  <typeConfig extensionType="Microsoft.Practices.Unity.Configuration.TypeInjectionElement, Microsoft.Practices.Unity.Configuration">
    <property name="RootUrl" propertyType="System.String">
      <value type="System.String" value="http://localhost:PortNumber"/>
    </property>
    <property name="WebmasterEmail" propertyType="System.String">
      <value type="System.String" value="admin@YOUR-DOMAIN.com"/> 
    </property>
    <property name="SupportEmail" propertyType="System.String">
      <value type="System.String" value="support@YOUR-DOMAIN.com"/>
    </property>
    <property name="DefaultEmailOfOpenIdUser" propertyType="System.String">
      <value type="System.String" value="openiduser@YOUR-DOMAIN.com"/>
    </property>
    <property name="SiteTitle" propertyType="System.String">
      <value type="System.String" value="YOUR-SITE-TITLE"/>
    </property>
    <property name="MetaKeywords" propertyType="System.String">
      <value type="System.String" value="YOUR-META-KEYWORDS"/>
    </property>
    <property name="MetaDescription" propertyType="System.String">
      <value type="System.String" value="YOUR-META-DESCRIPTION"/>
    </property>
    <property name="TopTags" propertyType="System.Int32">
      <value type="System.Int32" value="50"/>
    </property>
    <property name="HtmlStoryPerPage" propertyType="System.Int32">
      <value type="System.Int32" value="20"/>
    </property>
    <property name="FeedStoryPerPage" propertyType="System.Int32">
      <value type="System.Int32" value="25"/>
    </property>
    <property name="CarouselStoryCount" propertyType="System.Int32">
      <value type="System.Int32" value="5"/>
    </property>
    <property name="HtmlUserPerPage" propertyType="System.Int32">
      <value type="System.Int32" value="20"/>
    </property>
    <property name="TopUsers" propertyType="System.Int32">
      <value type="System.Int32" value="20"/>
    </property>
    <property name="AutoDiscoverContent" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="SendPing" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="PromoteText" propertyType="System.String">
      <value type="System.String" value="Shout it"/>
    </property>
    <property name="DemoteText" propertyType="System.String">
      <value type="System.String" value="Mute it"/>
    </property>
    <property name="CountText" propertyType="System.String">
      <value type="System.String" value="shouts"/>
    </property>
    <!-- 4 Hours-->
    <property name="MinimumAgeOfStoryInHoursToPublish" propertyType="System.Single">
      <value type="System.Single" value="4"/>
    </property>
    <!-- 10 Days-->
    <property name="MaximumAgeOfStoryInHoursToPublish" propertyType="System.Single">
      <value type="System.Single" value="240"/>
    </property>
    <property name="AllowPossibleSpamStorySubmit" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="SendMailWhenPossibleSpamStorySubmitted" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="AllowPossibleSpamCommentSubmit" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="SendMailWhenPossibleSpamCommentSubmitted" propertyType="System.Boolean">
      <value type="System.Boolean" value="true"/>
    </property>
    <property name="PublishedStoriesFeedBurnerUrl" propertyType="System.String">
      <value type="System.String" value="http://feeds.feedburner.com/YOUR-DOMAIN-Published"/>
    </property>
    <property name="UpcomingStoriesFeedBurnerUrl" propertyType="System.String">
      <value type="System.String" value="http://feeds.feedburner.com/YOUR-DOMAIN-Upcoming"/>
    </property>
    <property name="MaximumUserScoreToShowCaptcha" propertyType="System.Decimal">
      <value type="System.Decimal" value="25.0"/>
    </property>
    <property name="StorySumittedThresholdOfUserToSpamCheck" propertyType="System.Int32">
      <value type="System.Int32" value="5"/>
    </property>
  </typeConfig>
</type>
{code:xml}
Below we are going to explore each property of the above settings so that you should be able to define the proper value for each one.

### KiGG Configuration Settings Properties
* **RootUrl:** This should be the URL of your website. If you are running KiGG locally this could be "http://localhost:8081" or if you install it in a virtual directory it should be "http://localhost/KiGG" with no "/" at the end.
* **WebmasterEmail:** E-mail of site administrator/webmaster. Below are cases where this e-mail is uses as a sender of all e-mails such registration information email, password reset, comment subscription notification etc...
* **SupportEmail:** E-mail of site support. This e-mail is used as primary receiver of specific e-mails such as possible spam notification for stories or comments and feedback emails sent from site feedback form.
* **DefaultEmailOfOpenIdUser:** Because e-mail is mandatory field, and because some OpenID providers do not return e-mail as part of the response upon authentication. This e-mail is used as default e-mail for OpenID users who have no e-mail specified. Kind of dummy or placeholder.
* **SiteTitle:** Website title. The title might be composed as the following "{SiteTitle}-Latest published stories", "{SiteTitle}-Upcoming stories". Which means its more like site title prefix or main site title. The other parts are currently hardcoded inside the kigg.web.dll assembly.
* **MetaKeywords:** Site keywords _coma separated_ that will be use as website meta keywords. Will construct the _content_ attribute of <meta name="**keywords**" content="MetaKeywords"/>
* **MetaDescription:** Site description that will be used as website meta description.Will construct the _content_ attribute of <meta name="**description**" content="MetaDescription"/>
* **TopTags:** Total number of tags to be displayed in popular (_top_) tags could area.
* **HtmlStoryPerPage:** Total number of stories to be display per page. This is applied to all pages such as latest published stories and upcoming stories pages.
* **FeedStoryPerPage:** Total number of stories to be display on feed page.
* **CarouselStoryCount:** _Not yet impelemented or used_.
* **HtmlUserPerPage:** Total number of users to be displayed per page. Used in users page that is used to display list of all users paged.
* **TopUsers:** This is different than **HtmlUserPerPage** property. This property is about total number of top users to be displayed on leaders board area for both top daily movers and top leaders.
* **AutoDiscoverContent:** This a boolean (true/false) property. Used to specify whether to discover story content upon story submission or not.
* **SendPing:** This is a boolean (true,false) property. Used to specify whether to send ping to configured ping servers or not.
* **PromoteText:** Text to be used as label of promoting button/link. Like in dotnetshoutout.com it is "Shout It", it can be anything else such as "Kick it!" or "Burn it!" etc...
* **DemoteText:** Text to be used as label demoting button/link. In dotnetshoutout.com it is "Mute It", it can be anything else such as "Destroy it!" or "Sink It!" :o) etc...
* **CountText:** Text to be used as label beside the number of promotions. In dotnetshoutout.com it is "Shouts", it can be anything else like "Kicks" or "Burns" etc...
* **MinimumAgeOfStoryInHoursToPublish:** This is a number that represents the minimum story age in _hours_ that is required before considering publishing is to a front page. So if the value is "4" that means stories of age less than 4 hours shouldn't be published to front page.
* **MaximumAgeOfStoryInHoursToPublish:** This is a number that represents the maximum story age _hours_ to be considered as publishable story on front page. So if the value is "240" that means stories of age greater than 10 days shouldn't be published to front page.
* **AllowPossibleSpamStorySubmit:** This is a boolean (true/false) property. Used to specify whether possible spam stories to be submitted or not. Possible spams are not necessary be actual spams.
* **SendMailWhenPossibleSpamStorySubmitted:** This is a boolean (true/false) property. Used to specify whether to send an e-mail to support if possible spam story submitted. This is good for moderation and monitoring. Recommended value "_true_" if the above property **AllowPossibleSpamStorySubmit** is stet to "_true_".
* **AllowPossibleSpamCommentSubmit:** This is a boolean (true/false) property. Used to specify whether to allow possible spam comments to be submitted on stories or not. Possible spams are not necessary be actual spams.
* **SendMailWhenPossibleSpamCommentSubmitted:** This is a boolean (true/false) property. Used to specify whether to send an e-mail to support if possible spam comment submitted. This is good for moderation and monitoring. Recommended value "_true_" if the above property **AllowPossibleSpamCommentSubmit** is stet to "_true_".
* **PublishedStoriesFeedBurnerUrl:** Feedburner URL for published stories. When you subscribe to feedburner and provide your actual published feed url e.g."_http://yourkiggsite.com/Feed/rss/Published_" Feedburner will provide you with custom feed url. For more information visit [http://feedburner.google.com](http://feedburner.google.com). If no value specified original value will be used "_http://yourkiggsite.com/Feed/rss/Published_"
* **UpcomingStoriesFeedBurnerUrl:** Feedburner URL for upcoming stories. This is different from the above URL, as each one has different original feed url. Upcoming feed is similar to this "_http://yourkiggsite.come/Feed/rss/Upcoming_". If no value specified original value will be used "_http://yourkiggsite.com/Feed/rss/Upcoming_"
* **MaximumUserScoreToShowCaptcha:** This is a number value. Captcha is a way of spam protection to identify humans from robots. Each user has to verify the captcha by entering generated captcha verification code. The value provided in this property is to indicate that total score user should reach in order not to display captcha for him upon submitting story or comments. Trusted users don't require verification.
* **StorySumittedThresholdOfUserToSpamCheck:** This is a number value. This is a threshold to start check for spam if the user reached this limit in short amount of time. 